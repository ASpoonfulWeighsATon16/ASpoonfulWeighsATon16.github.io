var map;
var place;
var autocomplete;
var baseMapLayer = 1;  // controls which basemap attribute is depicted.  Will change based on dropdown menu value.
var infowindow = new google.maps.InfoWindow();

function initialization() {
    showCrimes();
    initAutocomplete();
}

function showCrimes() {
    $.ajax({
        url: 'HttpServlet',
        type: 'POST',
        data: { "tab_id": "1"},
        success: function(crimes) {
            mapInitialization(crimes);
            setBaseMap();
        },
        error: function(xhr, status, error) {
            alert("An AJAX error ocurred: " + status + "\nError: " + error);
        }
    });
}

function mapInitialization(crimes) {
    var mapOptions = {
        mapTypeId: google.maps.MapTypeId.ROADMAP, // Set the type of Map
    };

    // Render the map within the empty div
    map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

    var bounds = new google.maps.LatLngBounds();
    var heatmapData = [];

    $.each(crimes, function (i, e) {
        var long = Number(e['longitude']);
        var lat = Number(e['latitude']);
        // console.log(long);
        //  console.log(lat);
        if (long != -1.7976931348623157e+308) {
                var latlng = new google.maps.LatLng(lat, long);
                heatmapData.push(latlng);
                bounds.extend(latlng);
        }

        //Pop up Window Content

        var crimeInfoStr = '<h4>Crime Incident Detail</h4><hr>';
        crimeInfoStr += '<p><b>' + 'Date of Incident' + ':</b>&nbsp' + e['INCTDTE'] + '</p>';
        crimeInfoStr += '<p><b>' + 'Date of Reporting' + ':</b>&nbsp' + e['INCREPODT'] + '</p>';
        crimeInfoStr += '<p><b>' + 'Category' + ':</b>&nbsp' + e['CATEGORY'] + '</p>';
        crimeInfoStr += '<p><b>' + 'Description' + ':</b>&nbsp' + e['STATDESC'] + '</p>';
        crimeInfoStr += '<p><b>' + 'Address' + ':</b>&nbsp' + e['ADDRESS'] + '</p>';
        crimeInfoStr += '<p><b>' + 'Incident Number' + ':</b>&nbsp' + e['INCIDID'] + '</p>';
        crimeInfoStr += '<p><b>' + 'Gang Related?' + ':</b>&nbsp' + e['GANGRELAT'] + '</p>';
        crimeInfoStr += '<p><b>' + 'Unit Name' + ':</b>&nbsp' + e['UNITNAME'] + '</p>';

        //  if ('message' in e){
        //     contentStr += '<p><b>' + 'Message' + ':</b>&nbsp' + e['message'] + '</p>';
        //  }

        //****************************************************************************

        // Icon images for markers
        var icon_img = '';

        if (e['CATEGORY'] === 'DRUNK DRIVING VEHICLE / BOAT') {
            icon_img = 'http://cdn.onlinewebfonts.com/svg/img_332409.png';
        } else if (e['CATEGORY'] === 'NARCOTICS') {
            icon_img = 'https://cdn0.iconfinder.com/data/icons/medical-5/450/capsule-512.png';
        } else if (e['CATEGORY'] === 'BURGLARY') {
            icon_img = 'http://chittagongit.com//images/burglar-icon/burglar-icon-13.jpg';
        } else if (e['CATEGORY'] === 'CRIMINAL HOMICIDE') {
            icon_img = 'https://static.thenounproject.com/png/225529-200.png';
        }

        var icon = {
            url: icon_img, // url
            scaledSize: new google.maps.Size(40, 30), // scaled size
            origin: new google.maps.Point(0, 0), // origin
            anchor: new google.maps.Point(0, 0) // anchor
        };

        var marker = new google.maps.Marker({
            position: latlng,
            map: map,
            icon: icon,
            //zoom: 10,
            customInfo: crimeInfoStr

        });

        // var icon = {
        //     url: 'https://cdn1.iconfinder.com/data/icons/guns-3/512/police-gun-pistol-weapon-512.png', // url
        //     scaledSize: new google.maps.Size(30, 30), // scaled size
        //     origin: new google.maps.Point(0, 0), // origin
        //     anchor: new google.maps.Point(0, 0) // anchor
        // };
        //




        //Add a Click Listener to the marker
        google.maps.event.addListener(marker, 'click', function () {
            infowindow.setContent(marker['customInfo']);
            infowindow.open(map, marker); // Open InfoWindow
        });

        map.fitBounds(bounds);
        //console.log(bounds);
    });
    var heatmap = new google.maps.visualization.HeatmapLayer({
        data: heatmapData,
        dissipating: false,
        map: map
    });
    heatmap.setMap(map);
}

//*********************************************************************************************
//The setBaseMap function is used to depict basemap demographic layers based on user selections

function setBaseMap() {
    var demographicLayer = new google.maps.Data();
    demographicLayer.loadGeoJson('data/demwgs2016.json');  // basemap Census tract data
    var attribute;  // stores the attribute being mapped.
    var attributeLabel;
    var extraChar = "%"
    var colorArray = [];  // stores values for depicting tract fill colors
    var valueArray = [];  // stores values for class breaks

    if (baseMapLayer == 1) {  // mean income settings
      attribute = 'medinc';
      attributeLabel = 'Median Household Income';
      colorArray = ['#89a844', '#acd033', '#cbd97c','#c2c083','#d1ccad'];
      valueArray = [105951, 79511, 62101, 47919]
      extraChar = "$"
    }

   // sets the style of the basemap layer
    demographicLayer.setStyle(function(feature) {
        return {
            fillColor: getColor(feature.getProperty(attribute)), // sets color and class breaks of censu tracts
            fillOpacity: 0.8,
            strokeColor: '#b3b3b3',
            strokeWeight: 1,
            zIndex: 1
        };
    });
    demographicLayer.setMap(map)

// returns a color based on the value given when the function is called
    function getColor(val) {
        return val >= valueArray[0] ? colorArray[0] :
               val > valueArray[1] ? colorArray[1] :
                   val > valueArray[2] ? colorArray[2] :
                       val > valueArray[3] ? colorArray[3] :
                           colorArray[4];
    }

    // highlight census tract on mouse over
    demographicLayer.addListener('mouseover', function(e) {
        demographicLayer.overrideStyle(e.feature, {
            strokeColor: '#ffffff',
            strokeWeight: 1,
            zIndex: 2
        });
    });

    // reset layer on mouseout
    demographicLayer.addListener('mouseout', function(e) {
        demographicLayer.revertStyle();
    });

    // popup with census tract data
    demographicLayer.addListener('click', function(e) {
        console.log(e);
        infowindow.setContent('<div style="line-height:1.00;overflow:hidden;white-space:nowrap;">' +
            '<p><b>' + 'Census Tract' + ':</b>&nbsp' +  e.feature.getProperty('Geography') + '</p>' +
            '<p><b>' + attributeLabel + ':</b>&nbsp' + extraChar +  e.feature.getProperty(attribute) + '</p></div>');

        var anchor = new google.maps.MVCObject();
        anchor.set("position", e.latLng);
        infowindow.open(map, anchor);
    });
}

//*******************************************************************************************
function initAutocomplete() {
    // Create the autocomplete object
    autocomplete = new google.maps.places.Autocomplete(document.getElementById('autocomplete'));
    // When the user selects an address from the dropdown, show the place selected
    //  autocomplete.addListener('place_changed', onPlaceChanged);
}

google.maps.event.addDomListener(window, 'load', initialization);



/*
// Below is my code for Question 3 to zoom to the selected place
// *************************************************************
function onPlaceChanged() {
    place = autocomplete.getPlace();
    var placeMarker = new google.maps.Marker({
        map: map,
        anchorPoint: new google.maps.Point(0,0)
    });
    placeMarker.setVisible(false);

    // Check to see if the selected place is valid.  If not, notify user
    if (!place.geometry) {
        window.alert("'" + place.name + "'" + " could not be found.  Please try again");
        return;
    }

    // If place is valid, zoom to location
    if (place.geometry) {
        map.panTo(place.geometry.location);
        map.setZoom(13);
      //  placeMarker.setPosition(place.geometry.location);
      //  placeMarker.setVisible(true);
    }
}


//Execute our 'initialization' function once the page has loaded.
google.maps.event.addDomListener(window, 'load', initialization);

// createReport Function for question 4
//**************************************************************************
function queryReport(event) {
    event.preventDefault(); // stop form from submitting normally
    var a = $("#query_report_form").serializeArray();
    a.push({ name: "tab_id", value: "1" });
    a = a.filter(function(item){return item.value != '';});
    $.ajax({
        url: 'HttpServlet',
        type: 'POST',
        data: a,
        success: function(crimes) {
            mapInitialization(crimes);
        },
        error: function(xhr, status, error) {
            alert("Status: " + status + "\nError: " + error);
        }
    });
}

$("#query_report_form").on("submit",queryReport);


// createReport Function for question 4
//**************************************************************************

function createReport(event) {
    event.preventDefault(); // stop form from submitting normally`
    var reportForm = document.getElementById("create_report_form");
    var a = $("#create_report_form").serializeArray();

    // Make sure that a place is entered and that it has valid geometry.
    // If not, provide an alert and reset the form
    if (place != null && place.geometry) {
        var latNum = place.geometry.location.lat();
        var lonNum = place.geometry.location.lng();
        var latStr = latNum.toString();
        var lonStr = lonNum.toString();
        a.push({name: "longitude", value: lonStr});
        a.push({name: "latitude", value: latStr});

        // set the place to null in case next report attempt uses invalid place and previous place remains as a global variable
        place = null;
    } else {
        window.alert("A valid place needs to be entered for your report. Please try again");
        reportForm.reset(); // reset the create report form
        $(reportForm).find(".additional_msg_div").css("visibility", "hidden"); // hide additional message
        return;
    }

    a.push({name: "tab_id", value: "0"});
    console.log(a); // check array keys/values

    a = a.filter(function(item){return item.value != '';});
    $.ajax({
        url: 'HttpServlet',
        type: 'POST',
        data: a,
        success: function(crimes) {
            showCrimes();  // Show all crimes also calls mapInitialization
            reportForm.reset(); // reset the create report form
            $(reportForm).find(".additional_msg_div").css("visibility", "hidden"); // hide additional message
            window.alert("The report is successfully submitted!"); // inform user that report was successful
         },
        error: function(xhr, status, error) {
            alert("Status: " + status + "\nError: " + error);
        }
    });
}

$("#create_report_form").on("submit",createReport);

*/